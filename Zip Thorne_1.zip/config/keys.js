
module.exports = {
    MongoURI:'mongodb+srv://Thorne:Thorne@cluster0.9t4mj.mongodb.net/myFirstDatabase?retryWrites=true&w=majority'
}
